document.addEventListener("DOMContentLoaded", async ()=>{
const video=document.getElementById("videoPlayer");
const subtitle=document.getElementById("subtitleContainer");
const status=document.getElementById("subtitleStatus");

const engine=new SubtitleEngine(video,subtitle);

const loaded=await engine.load("subtitles/indonesia.json");

if(loaded){
status.textContent="Aktif";
engine.start();
}else{
status.textContent="Gagal";
}

window.subtitleEngine=engine;
});
