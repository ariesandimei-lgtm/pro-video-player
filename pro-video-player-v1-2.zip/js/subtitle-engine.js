class SubtitleEngine{
constructor(video,container){
this.video=video;
this.container=container;
this.segments=[];
this.enabled=true;
}

async load(url){
const response=await fetch(url);
const data=await response.json();
this.segments=data.segments;
return true;
}

update(){
if(!this.enabled)return;

const time=this.video.currentTime;

const active=this.segments.find(
s=>time>=s.start && time<=s.end
);

this.container.textContent=active?active.text:"";
}

start(){
const loop=()=>{
this.update();
requestAnimationFrame(loop);
};
loop();
}

setEnabled(value){
this.enabled=value;
}
}
